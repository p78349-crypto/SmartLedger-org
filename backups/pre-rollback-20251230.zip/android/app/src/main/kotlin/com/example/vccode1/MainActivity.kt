package com.example.vccode1

import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream

class MainActivity : FlutterActivity() {
	companion object {
		private const val APP_ICON_CHANNEL = "vccode1/app_icon"
		private const val ICON_THEME_AUTO = "auto"
		private const val ICON_THEME_LIGHT = "light"
		private const val ICON_THEME_DARK = "dark"
	}

	override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
		super.configureFlutterEngine(flutterEngine)

		MethodChannel(flutterEngine.dartExecutor.binaryMessenger, APP_ICON_CHANNEL)
			.setMethodCallHandler { call, result ->
				when (call.method) {
					"getAppIconPngBytes" -> {
						try {
							val drawable = packageManager.getApplicationIcon(packageName)
							val bitmap = drawableToBitmap(drawable)
							val out = ByteArrayOutputStream()
							bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
							result.success(out.toByteArray())
						} catch (e: Exception) {
							result.error("APP_ICON_ERROR", e.message, null)
						}
					}
					"setLauncherIconTheme" -> {
						try {
							val theme = call.argument<String>("theme")?.trim()?.lowercase()
								?: call.argument<String>("id")?.trim()?.lowercase()
								?: call.arguments as? String
								?: ICON_THEME_AUTO

							setLauncherIconTheme(theme)
							result.success(true)
						} catch (e: Exception) {
							result.error("APP_ICON_THEME_ERROR", e.message, null)
						}
					}
					else -> result.notImplemented()
				}
			}
	}

	private fun setLauncherIconTheme(theme: String) {
		val autoAlias = "$packageName.MainActivityAliasAuto"
		val lightAlias = "$packageName.MainActivityAliasLight"
		val darkAlias = "$packageName.MainActivityAliasDark"

		val enableAlias = when (theme) {
			ICON_THEME_LIGHT -> lightAlias
			ICON_THEME_DARK -> darkAlias
			else -> autoAlias
		}

		val aliases = listOf(autoAlias, lightAlias, darkAlias)
		for (aliasName in aliases) {
			val desiredState = if (aliasName == enableAlias) {
				PackageManager.COMPONENT_ENABLED_STATE_ENABLED
			} else {
				PackageManager.COMPONENT_ENABLED_STATE_DISABLED
			}

			val component = ComponentName(this, aliasName)
			val currentState = packageManager.getComponentEnabledSetting(component)
			val effectiveCurrentState = when (currentState) {
				PackageManager.COMPONENT_ENABLED_STATE_DEFAULT -> {
					// Default means "use manifest value"; our manifest defaults are:
					// Auto: enabled, Light/Dark: disabled.
					if (aliasName == autoAlias) {
						PackageManager.COMPONENT_ENABLED_STATE_ENABLED
					} else {
						PackageManager.COMPONENT_ENABLED_STATE_DISABLED
					}
				}
				else -> currentState
			}

			if (effectiveCurrentState == desiredState) continue

			packageManager.setComponentEnabledSetting(
				component,
				desiredState,
				PackageManager.DONT_KILL_APP
			)
		}
	}

	private fun drawableToBitmap(drawable: Drawable): Bitmap {
		if (drawable is BitmapDrawable) {
			val bmp = drawable.bitmap
			if (bmp != null) return bmp
		}

		val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 128
		val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 128
		val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
		val canvas = Canvas(bitmap)
		drawable.setBounds(0, 0, canvas.width, canvas.height)
		drawable.draw(canvas)
		return bitmap
	}
}
