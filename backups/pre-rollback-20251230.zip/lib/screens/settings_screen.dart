import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vccode1/screens/_verify_current_user_password_dialog.dart';
import 'package:vccode1/screens/_verify_current_user_pin_dialog.dart';
import 'package:vccode1/services/auth_service.dart';
import 'package:vccode1/services/backup_service.dart';
import 'package:vccode1/services/user_password_service.dart';
import 'package:vccode1/services/user_pin_service.dart';
import 'package:vccode1/services/user_pref_service.dart';
import 'package:vccode1/utils/icon_catalog.dart';
import 'package:vccode1/utils/pref_keys.dart';
import 'package:vccode1/widgets/background_widget.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen>
    with WidgetsBindingObserver {
  bool _isLoading = true;
  bool _backupEncryptionEnabled = false;
  bool _backupTwoFactorEnabled = false;
  bool _userPinEnabled = false;
  bool _userPinConfigured = false;
  bool _userPasswordEnabled = false;
  bool _userPasswordConfigured = false;
  bool _userBiometricEnabled = false;

  bool _zeroQuickButtonsEnabled = false;
  final UserPinService _userPinService = UserPinService();
  final UserPasswordService _userPasswordService = UserPasswordService();
  final AuthService _authService = AuthService();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // 설정 앱(권한/알림 등)에서 돌아온 경우, 상태를 다시 읽어 UI를 갱신.
      _load();
    }
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final backupEncryptionEnabled =
        prefs.getBool(PrefKeys.backupEncryptionEnabled) ?? false;
    final backupTwoFactorEnabled =
        prefs.getBool(PrefKeys.backupTwoFactorEnabled) ?? false;

    final userPinEnabled = prefs.getBool(PrefKeys.userPinEnabled) ?? false;
    final userPinConfigured = _userPinService.isPinConfigured(prefs);

    final userPasswordEnabled =
        prefs.getBool(PrefKeys.userPasswordEnabled) ?? false;
    final userPasswordConfigured = _userPasswordService.isPasswordConfigured(
      prefs,
    );

    final userBiometricEnabled =
      prefs.getBool(PrefKeys.userBiometricEnabled) ?? false;
    final zeroQuickButtonsEnabled =
      prefs.getBool(PrefKeys.zeroQuickButtonsEnabled) ?? false;


    if (userPinEnabled && !userPinConfigured) {
      await prefs.setBool(PrefKeys.userPinEnabled, false);
    }
    if (userPasswordEnabled && !userPasswordConfigured) {
      await prefs.setBool(PrefKeys.userPasswordEnabled, false);
    }
    if (!mounted) return;
    setState(() {
      _backupEncryptionEnabled = backupEncryptionEnabled;
      _backupTwoFactorEnabled = backupTwoFactorEnabled;
      _userPinEnabled = userPinEnabled && userPinConfigured;
      _userPinConfigured = userPinConfigured;
      _userPasswordEnabled = userPasswordEnabled && userPasswordConfigured;
      _userPasswordConfigured = userPasswordConfigured;
      _userBiometricEnabled = userBiometricEnabled;
      _zeroQuickButtonsEnabled = zeroQuickButtonsEnabled;
      _isLoading = false;
    });
  }

  Future<void> _setZeroQuickButtonsEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await UserPrefService.setZeroQuickButtonsEnabled(enabled: enabled);
    await prefs.setBool(PrefKeys.zeroQuickButtonsEnabled, enabled);
    if (!mounted) return;
    setState(() => _zeroQuickButtonsEnabled = enabled);
  }

  Future<void> _setUserBiometricEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();

    if (enabled) {
      final can = await _authService.canUseDeviceAuth();
      if (!can) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('이 기기에서 지문(기기 인증)을 사용할 수 없습니다')),
        );
        return;
      }
    }

    await prefs.setBool(PrefKeys.userBiometricEnabled, enabled);
    if (!mounted) return;
    setState(() => _userBiometricEnabled = enabled);
  }

  Future<void> _setUserPasswordEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    final configured = _userPasswordService.isPasswordConfigured(prefs);

    if (enabled && !configured) {
      final didSet = await _showSetUserPasswordDialog();
      if (!didSet) {
        if (!mounted) return;
        setState(() {
          _userPasswordEnabled = false;
          _userPasswordConfigured = _userPasswordService.isPasswordConfigured(
            prefs,
          );
        });
        return;
      }
    }

    if (!enabled) {
      if (!mounted) return;
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (dialogContext) {
          return AlertDialog(
            title: const Text('비밀번호 해지'),
            content: const Text('유저 계정 비밀번호를 해지할까요?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(false),
                child: const Text('취소'),
              ),
              FilledButton(
                onPressed: () => Navigator.of(dialogContext).pop(true),
                child: const Text('해지'),
              ),
            ],
          );
        },
      );

      if (confirmed != true) {
        if (!mounted) return;
        setState(() => _userPasswordEnabled = true);
        return;
      }

      await _userPasswordService.clearPassword(prefs);
    }

    await prefs.setBool(PrefKeys.userPasswordEnabled, enabled);
    final configuredNow = _userPasswordService.isPasswordConfigured(prefs);
    if (!mounted) return;
    setState(() {
      _userPasswordEnabled = enabled && configuredNow;
      _userPasswordConfigured = configuredNow;
    });
  }

  Future<bool> _showSetUserPasswordDialog() async {
    final pwController = TextEditingController();
    final confirmController = TextEditingController();
    String? error;

    if (!mounted) {
      pwController.dispose();
      confirmController.dispose();
      return false;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: const Text('유저 계정 비밀번호 설정'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: pwController,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: '새 비밀번호',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: confirmController,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: '비밀번호 확인',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  if (error != null) ...[
                    const SizedBox(height: 8),
                    Text(
                      error!,
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                      ),
                    ),
                  ],
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(dialogContext).pop(false),
                  child: const Text('취소'),
                ),
                FilledButton(
                  onPressed: () {
                    final pw = pwController.text;
                    final confirm = confirmController.text;
                    if (pw.trim().length < 6) {
                      setDialogState(() {
                        error = '비밀번호는 최소 6자 이상이어야 합니다.';
                      });
                      return;
                    }
                    if (pw != confirm) {
                      setDialogState(() {
                        error = '비밀번호가 일치하지 않습니다.';
                      });
                      return;
                    }
                    Navigator.of(dialogContext).pop(true);
                  },
                  child: const Text('설정'),
                ),
              ],
            );
          },
        );
      },
    );

    if (confirmed != true) {
      pwController.dispose();
      confirmController.dispose();
      return false;
    }

    final prefs = await SharedPreferences.getInstance();
    final password = pwController.text;
    pwController.dispose();
    confirmController.dispose();

    await _userPasswordService.setPassword(prefs, password: password);
    if (!mounted) return true;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('유저 계정 비밀번호가 설정되었습니다')));
    return true;
  }

  Future<void> _changeUserPassword() async {
    final prefs = await SharedPreferences.getInstance();
    if (!_userPasswordService.isPasswordConfigured(prefs)) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('먼저 비밀번호를 설정하세요')));
      return;
    }

    if (!mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return VerifyCurrentUserPasswordDialog(
          prefs: prefs,
          service: _userPasswordService,
        );
      },
    );
    if (ok != true || !mounted) return;

    final didSet = await _showSetUserPasswordDialog();
    if (!didSet || !mounted) return;

    await prefs.setBool(PrefKeys.userPasswordEnabled, true);
    final configuredNow = _userPasswordService.isPasswordConfigured(prefs);
    setState(() {
      _userPasswordEnabled = configuredNow;
      _userPasswordConfigured = configuredNow;
    });
  }

  Future<void> _setUserPinEnabled(bool enabled) async {
    if (_isLoading) return;

    final prefs = await SharedPreferences.getInstance();
    final configured = _userPinService.isPinConfigured(prefs);

    if (enabled && !configured) {
      final didSet = await _showSetUserPinDialog();
      if (!didSet) {
        if (!mounted) return;
        setState(() {
          _userPinEnabled = false;
          _userPinConfigured = _userPinService.isPinConfigured(prefs);
        });
        return;
      }
    }

    if (!enabled) {
      if (!mounted) return;
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (dialogContext) {
          return AlertDialog(
            title: const Text('PIN 해지'),
            content: const Text('유저 계정 PIN을 해지할까요?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(false),
                child: const Text('취소'),
              ),
              FilledButton(
                onPressed: () => Navigator.of(dialogContext).pop(true),
                child: const Text('해지'),
              ),
            ],
          );
        },
      );

      if (confirmed != true) {
        if (!mounted) return;
        setState(() => _userPinEnabled = true);
        return;
      }

      await _userPinService.clearPin(prefs);
    }

    await prefs.setBool(PrefKeys.userPinEnabled, enabled);
    final configuredNow = _userPinService.isPinConfigured(prefs);
    if (!mounted) return;
    setState(() {
      _userPinEnabled = enabled && configuredNow;
      _userPinConfigured = configuredNow;
    });
  }

  Future<bool> _showSetUserPinDialog() async {
    final pinController = TextEditingController();
    final confirmController = TextEditingController();
    String? error;

    if (!mounted) {
      pinController.dispose();
      confirmController.dispose();
      return false;
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: const Text('유저 계정 PIN 설정'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: pinController,
                    obscureText: true,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: '새 PIN',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: confirmController,
                    obscureText: true,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'PIN 확인',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  if (error != null) ...[
                    const SizedBox(height: 8),
                    Text(
                      error!,
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                      ),
                    ),
                  ],
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(dialogContext).pop(false),
                  child: const Text('취소'),
                ),
                FilledButton(
                  onPressed: () {
                    final pin = pinController.text.trim();
                    final confirm = confirmController.text.trim();
                    if (pin.length < 4) {
                      setDialogState(() {
                        error = 'PIN은 최소 4자리 이상이어야 합니다.';
                      });
                      return;
                    }
                    if (pin != confirm) {
                      setDialogState(() {
                        error = 'PIN이 일치하지 않습니다.';
                      });
                      return;
                    }
                    Navigator.of(dialogContext).pop(true);
                  },
                  child: const Text('설정'),
                ),
              ],
            );
          },
        );
      },
    );

    if (confirmed != true) {
      pinController.dispose();
      confirmController.dispose();
      return false;
    }

    final prefs = await SharedPreferences.getInstance();
    final pin = pinController.text.trim();
    pinController.dispose();
    confirmController.dispose();
    await _userPinService.setPin(prefs, pin: pin);
    if (!mounted) return true;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('유저 계정 PIN이 설정되었습니다')));
    return true;
  }

  Future<void> _changeUserPin() async {
    final prefs = await SharedPreferences.getInstance();
    if (!_userPinService.isPinConfigured(prefs)) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('먼저 PIN을 설정하세요')));
      return;
    }

    if (!mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return VerifyCurrentUserPinDialog(
          prefs: prefs,
          service: _userPinService,
        );
      },
    );
    if (ok != true || !mounted) return;

    final didSet = await _showSetUserPinDialog();
    if (!didSet || !mounted) return;

    await prefs.setBool(PrefKeys.userPinEnabled, true);
    final configuredNow = _userPinService.isPinConfigured(prefs);
    setState(() {
      _userPinEnabled = configuredNow;
      _userPinConfigured = configuredNow;
    });
  }

  Future<void> _disableBackupEncryption() async {
    if (_isLoading) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('암호화 설정 해지'),
          content: const Text(
            '백업 암호화를 해지할까요?\n'
            '저장된 백업 암호가 삭제되고, 이후 백업은 암호 없이 저장될 수 있습니다.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('취소'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('해지'),
            ),
          ],
        );
      },
    );

    if (confirmed != true || !mounted) return;

    setState(() => _isLoading = true);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(PrefKeys.backupEncryptionEnabled, false);
    await prefs.setBool(PrefKeys.backupTwoFactorEnabled, false);
    await BackupService().clearStoredBackupEncryptionPassword();
    if (!mounted) return;
    setState(() {
      _backupEncryptionEnabled = false;
      _backupTwoFactorEnabled = false;
      _isLoading = false;
    });

    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('백업 암호화 설정을 해지했습니다')));
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Color>(
      valueListenable: BackgroundHelper.colorNotifier,
      builder: (context, bgColor, _) {
        return Scaffold(
          backgroundColor: bgColor,
      appBar: AppBar(title: const Text('설정')),
      body: ListView(
        children: [
          // '테마' 및 '배경 설정'은 메인 페이지(9)에 아이콘으로 제공됩니다.
          ListTile(
            leading: const Icon(Icons.admin_panel_settings_outlined),
            title: const Text('앱 설정 열기'),
            subtitle: const Text('권한(알림/파일 등)은 기기 설정에서 변경합니다.'),
            trailing: const Icon(IconCatalog.chevronRight),
            onTap: () async {
              await openAppSettings();
              // 돌아오면 didChangeAppLifecycleState(resumed)에서 자동 갱신됩니다.
            },
          ),
          const ListTile(
            title: Text('백업 암호화'),
            subtitle: Text('해지는 설정에서만 가능합니다.'),
          ),
          ListTile(
            leading: const Icon(Icons.lock_open_outlined),
            title: const Text('백업 암호화 해지'),
            subtitle: Text(
              (_backupEncryptionEnabled || _backupTwoFactorEnabled)
                  ? '상태: 사용'
                  : '상태: 미사용',
            ),
            onTap:
                (_isLoading ||
                    (!_backupEncryptionEnabled && !_backupTwoFactorEnabled))
                ? null
                : _disableBackupEncryption,
          ),
          const ListTile(
            title: Text('사용자 계정 잠금'),
            subtitle: Text('계정 진입 시 PIN을 요청합니다.'),
          ),
          const ListTile(
            title: Text('사용자 계정 인증'),
            subtitle: Text('자산/ROOT/백업 보호에 동일 적용됩니다.'),
          ),
          SwitchListTile(
            secondary: const Icon(Icons.password_outlined),
            title: const Text('비밀번호 사용'),
            subtitle: Text(
              _userPasswordConfigured
                  ? (_userPasswordEnabled ? '상태: 사용' : '상태: 미사용')
                  : '상태: 미설정',
            ),
            value: _userPasswordEnabled,
            onChanged: _isLoading ? null : _setUserPasswordEnabled,
          ),
          ListTile(
            leading: const Icon(Icons.password_outlined),
            title: const Text('비밀번호 변경'),
            subtitle: const Text('기존 비밀번호 확인 후 변경'),
            onTap: (_isLoading || !_userPasswordEnabled)
                ? null
                : _changeUserPassword,
          ),
          SwitchListTile(
            secondary: const Icon(Icons.lock_outline),
            title: const Text('사용자 계정 PIN 사용'),
            subtitle: Text(
              _userPinConfigured
                  ? (_userPinEnabled ? '상태: 사용' : '상태: 미사용')
                  : '상태: 미설정',
            ),
            value: _userPinEnabled,
            onChanged: _isLoading ? null : _setUserPinEnabled,
          ),
          ListTile(
            leading: const Icon(Icons.password_outlined),
            title: const Text('PIN 변경'),
            subtitle: const Text('기존 PIN 확인 후 변경'),
            onTap: (_isLoading || !_userPinEnabled) ? null : _changeUserPin,
          ),
          SwitchListTile(
            secondary: const Icon(Icons.fingerprint),
            title: const Text('기기 인증 사용'),
            subtitle: const Text('지문/잠금화면 등 기기 인증을 사용합니다.'),
            value: _userBiometricEnabled,
            onChanged: _isLoading ? null : _setUserBiometricEnabled,
          ),
          SwitchListTile(
            secondary: const Icon(IconCatalog.keyboardAltOutlined),
            title: const Text('숫자 입력 보조'),
            subtitle: const Text('숫자 입력 시 0/00/000 버튼을 표시합니다.'),
            value: _zeroQuickButtonsEnabled,
            onChanged: _isLoading ? null : _setZeroQuickButtonsEnabled,
          ),
          // '화면 보호 설정'은 ROOT 전용 기능으로 메인 ROOT 페이지에서 제공합니다.
          const Divider(),
          ListTile(
            leading: const Icon(Icons.description_outlined),
            title: const Text('오픈소스 라이선스'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              showLicensePage(
                context: context,
                applicationName: 'vccode1',
                applicationLegalese: 'Copyright (c) 2025 com.example',
              );
            },
          ),
        ],
      ),
    );
      },
    );
  }
}
