import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vccode1/services/app_icon_service.dart';
import 'package:vccode1/theme/theme_preset.dart';
import 'package:vccode1/utils/pref_keys.dart';

class AppThemeSeedController {
  AppThemeSeedController._();

  static final AppThemeSeedController instance = AppThemeSeedController._();

  final ValueNotifier<String> presetId = ValueNotifier<String>(
    ThemePresets.defaultId,
  );

  Future<void> loadFromPrefs(SharedPreferences prefs) async {
    final raw = prefs.getString(PrefKeys.themePresetId);
    presetId.value = _normalizePresetId(raw);
  }

  Future<void> setPresetId(String id) async {
    final next = _normalizePresetId(id);
    if (presetId.value == next) return;
    presetId.value = next;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(PrefKeys.themePresetId, next);

    // Minimal system impact: change launcher icon only when user changes preset.
    if (!kIsWeb && defaultTargetPlatform == TargetPlatform.android) {
      final isFemale = ThemePresets.female.any((p) => p.id == next);
      final iconThemeId = isFemale ? 'light' : 'dark';
      await AppIconService.setLauncherIconTheme(iconThemeId);
    }
  }

  static String _normalizePresetId(String? raw) {
    final trimmed = (raw ?? '').trim();
    final resolved = ThemePresets.byId(trimmed).id;
    return resolved;
  }
}
