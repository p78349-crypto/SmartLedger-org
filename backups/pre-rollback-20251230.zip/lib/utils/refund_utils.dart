import 'package:flutter/material.dart';

import 'package:vccode1/utils/icon_catalog.dart';

class RefundUtils {
  RefundUtils._();

  static const IconData icon = IconCatalog.refund;

  // Use a stable MaterialColor constant (no shade index).
  static const Color color = Colors.green;
}
