// QuickActions feature removed.
