﻿Offline AI Package Manifest

Created: 20260112_161017
Includes:
- tools/offline_ai_server/*
- tools/OFFLINE_AI_ROADMAP.md
- scripts/install_vosk_model.ps1
- assets/ai/README.md
- lib/services/offline_ai_service.dart
- lib/widgets/voice_input_button.dart

Instructions:
- Unzip into your new project root or desired location.
- Follow tools/offline_ai_server/README.md to run the prototype server.
- Do NOT commit large model files into git; use model download or external hosting.
